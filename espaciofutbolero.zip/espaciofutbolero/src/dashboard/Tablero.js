import { BrowserRouter as Router, Routes, Route, Link, } from 'react-router-dom';
import { CategoriasCrear } from '../Categorias/CategoriasCrear';
import { CategoriasListar } from '../Categorias/CategoriasListar';

export function Tablero(){
    return <div className="row">
        <div className="col-3">
            <h2>Menú</h2>
            <ul>
                <li><h4>Categorias</h4></li>
                <ul>
                    <li><Link to='/Tablero/categoriascrear'><h5>Crear</h5></Link></li>
                    <li><Link to='/Tablero/categoriaslistar'><h5>Listar</h5></Link></li>
                </ul>
                <li><h4>Equipos</h4></li>
            </ul>
        </div>
        <div className="col-9">
            <h2>Tabla de datos</h2>
                <div className='container'>
                    <div className='row alfg-center'>
                    <div className='col m-5'>
                        <Routes>
                            <Route path='/categoriascrear' element={<CategoriasCrear/>}></Route>
                            <Route path='/categoriaslistar' element={<CategoriasListar/>}></Route>
                        </Routes>
                    </div>
                    </div>
                </div>
            </div>
    </div>
}