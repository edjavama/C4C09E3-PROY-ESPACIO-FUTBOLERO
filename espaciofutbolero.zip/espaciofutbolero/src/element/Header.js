import 'bootstrap/dist/css/bootstrap.min.css'

export function Header(){
    return<h1>Bienvenido al espacio futbolero</h1>
} 

/*export function Menu(){
    return<nav>Inicio</nav>
}*/
export default Header