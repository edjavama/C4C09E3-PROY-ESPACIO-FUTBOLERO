import { BrowserRouter as Router, Link } from "react-router-dom"
export function Menu(){
    return <div>
        <nav className="navbar navbar-expand-lg bg-success">
          <div className="container-fluid">
            <Link className="navbar-brand fw-bold text-white">Espacio Futbolero</Link>
            <Link className="navbar-brand fw-bold text-white">Bienvenido</Link>
            <Link className="navbar-brand fw-bold text-white">Colombia</Link>
          </div>
        </nav>
        <nav className="navbar navbar-expand-lg bg-success bg-opacity-75">
          <div className="container-fluid">
            <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
              <span className="navbar-toggler-icon"></span>
            </button>
            <div className="collapse navbar-collapse" id="navbarSupportedContent">
              <ul className="navbar-nav me-auto mb-2 mb-lg-0 w-100">
                <li className="nav-item">
                  <Link className="nav-link active fw-bold text-white" aria-current="page" to="#">Inicio</Link>
                </li>
                <li className="nav-item flex-fill">
                  <Link className="nav-link active fw-bold text-white" to="#">Clubes</Link>
                </li>
                <li className="nav-item flex-fill">
                  <Link className="nav-link active fw-bold text-white" to="/Tablero">Categorias</Link>
                </li>
                <li className="nav-item flex-fill">
                  <Link className="nav-link active fw-bold text-white" to="#">Campeonatos</Link>
                </li>
                <li className="nav-item flex-fill">
                  <Link className="nav-link active fw-bold text-white" to="#">Estadios</Link>
                </li>
                <li className="nav-item flex-fill">
                  <Link className="nav-link active fw-bold text-white" to={'/www.fifa.com/fifaplus/es/tournaments/mens/worldcup/qatar2022'} target="_blank">Mundial</Link>
                </li>
                <li className="nav-item flex-fill">
                    <Link className="nav-link active fw-bold text-white" to="#">Contactenos</Link>
                </li>
                <li className="nav-item flex-fill">
                  <Link className="nav-link active fw-bold text-white" to="#">Quienes Somos</Link>
                </li>
                <li className="nav-item flex-fill">
                  <Link className="nav-link active fw-bold text-white" to="#">Registrase</Link>
                </li>
                <li className="nav-item flex-fill">
                  <Link className="btn btn-outline-success text-white" type="submit" to="/Login">Ingresar</Link>
                  {/*<Link className="nav-link active fw-bold text-white" to="#">Ingresar</Link>*/}
                </li>
              </ul>
            </div>
          </div>
        </nav>
    </div>
  
}