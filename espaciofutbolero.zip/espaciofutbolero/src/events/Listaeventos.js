import { Evento } from "./Evento";

export function Listaeventos(){
    return <div className="col-sm-6">
        <Evento/>
        <Evento/>
    </div>
}