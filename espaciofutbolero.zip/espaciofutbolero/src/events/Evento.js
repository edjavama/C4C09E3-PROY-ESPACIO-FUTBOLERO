import { BrowserRouter as Route, Link } from "react-router-dom"
export function Evento(props){
    return<div className="row">
        <div className="col"><h5>Equipo 1</h5></div>
        <div className="col"><h4>4</h4></div>
        <div className="col"><h4>-</h4></div>
        <div className="col"><h4>2</h4></div>
        <div className="col"><h5>Equipo 2</h5></div>
    </div>
}