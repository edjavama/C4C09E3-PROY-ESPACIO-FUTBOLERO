import React from 'react'
import ReactDOM from 'react-dom/client'
//import {Mensaje, Registrados} from './Mensaje'
import {Header} from './element/Header'
import { Menu } from './element/Menu'
//import { Evento } from './Evento'
//import { Equipos } from './Equipos'
//import { Example } from './Example'
import 'bootstrap/dist/css/bootstrap.min.css'
//import { Listaeventos } from './events/Listaeventos'
import { BrowserRouter as Router, Routes, Route, } from 'react-router-dom';
import { Tablero } from './dashboard/Tablero'
//import { Login } from './events/Login'

const root=ReactDOM.createRoot(document.getElementById('root'))
root.render(<div>
  <Header/>
  <Router>
    <Menu/>
        <div className='container'>
            <div className='row alfg-center'>
              <div className='col m-5'>
                <Routes>
                  <Route path='/Tablero/*' element={<Tablero/>}></Route>
                  {/*<Route path='/Login' component={<Login/>}></Route>*/}
                </Routes>
              </div>
            </div>
        </div>
  </Router>
</div>)