export function Mensaje(){
  const texto='el numero de equipos es: '
  const equipos=20
  const evento={
    nombre:'partidos',
    marcador1:4,
    marcador2:3
  }
  function msj(){
    <h1>HOY JUEGA</h1>
  }

  function ganador(r1,r2){
    if(r1===r2)
      return<h3>Es un empante</h3>
    else
      if(r1>r2)
        return<h3>r1 es el ganador</h3>
      else
        return<h3>r2 es el ganador</h3>
  }

  return <div>
          <h1>espacio futbolero</h1>
          <p>ejemplos de equipos</p>
          <p>{texto}{equipos}</p>
          <p>{evento.nombre}</p>
          <p>{evento.marcador1} - {evento.marcador2}</p>
          {msj()}
          {ganador(evento.marcador1, evento.marcador2)}
      </div>
}

export function Registrados(){

}
