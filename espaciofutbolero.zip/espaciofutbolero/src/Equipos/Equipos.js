import './css/style.css'

export function Equipos(props){
    const etiqueta={
        color:'green',
        border:'1px solid blue',
        width:'350px',
        display:'block'
    }
    return <div style={etiqueta}>
        <ul>
        <li>nombre:{props.nombre}</li>
        <li>partidos jugados:{props.jugados}</li>
        <li>promedio:{props.promedio}</li>
        <li>ultimosjugados:{props.ultimos}</li>
        <li>record:ganados{props.record[0]}/perdidos{props.record[1]}</li>
        <li>juegos internaciones:{props.internacional ? 'si':'no'}</li>
        <li>ubicados en: {props.ubicado.pais}/{props.ubicado.ciudad}</li>
        </ul>
    </div>
}