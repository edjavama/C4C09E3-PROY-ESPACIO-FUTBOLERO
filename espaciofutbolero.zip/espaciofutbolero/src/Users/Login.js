export function Login(){
    const escribir=function(){console.log('escribiendo')}
    const pressboton=function(){console.log('enviado datos')}
    const handleSubmit=(ev)=>{
        ev.prevenDefault()
        console.log('enviando datos '+ev)
    }
    return <div className="container-fuid">
        <div className="row">
        <div className="col-md-4 offset-4">
        <form onSubmit={handleSubmit}>
            <div className="mb-3">
                <label for="exampleInputEmail1" class="form-label">Email address</label>
                <input type="email" className="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" onChange={escribir}/>
                <div id="emailHelp" className="form-text">We'll never share your email with anyone else.</div>
            </div>
            <div className="mb-3">
                <label for="exampleInputPassword1" class="form-label">Password</label>
                <input type="password" className="form-control" id="exampleInputPassword1"/>
            </div>
            <div className="mb-3 form-check">
                <input type="checkbox" className="form-check-input" id="exampleCheck1"/>
                <label className="form-check-label" for="exampleCheck1">Check me out</label>
            </div>
            <button type="submit" className="btn btn-primary" onClick={pressboton}>Submit</button>
        </form>
        </div>
        </div>
    </div>
}