import { url } from "../element/Const"
import React, { useRef } from "react"

export function CategoriasCrear(){
    const refNombre=useRef(null) 
    const HandleSubmit=(ev)=>{
        ev.preventDefault()
        console.log('enviando datos')
        const requestOptions={
            method:'POST',
            headers:{'Content-Type':'application/json'},
            mode:'cors',
            body:JSON.stringify({nombre:refNombre.current.value})
        }
        fetch(url+'/categorias/',requestOptions)
        .then(response => response.json())
        .then(data => console.log(data))
        .catch(error => console.log('el error'+error))
    } 
    return <div>
        <h2>Crear Categorias</h2>
        <div className="container-fluid">
        <div className="row ">
        <div className="col-md-4 offset-4">
        <form  onSubmit={HandleSubmit}>
            <div className="mb-3">
                <label for="exampleInputName" className="form-label">Nombre Categoría</label>
                <input type="text" className="form-control" id="exampleInputname" aria-describedby="nombre Categoría" ref={refNombre}/>
            </div>
            <button type="submit" className="btn btn-primary" >Registrar</button>
        </form>
        </div>
        </div>
        </div>
    </div>
}