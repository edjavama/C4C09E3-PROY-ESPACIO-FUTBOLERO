import React, {useState, useEffect} from "react"
import { url } from "../element/Const"

export function CategoriasListar(){
    const [categorias,setCategorias]=useState([])
    function Listar(){
        const requestOptions={
            method:'GET',
            Headers:{'Content_Type':'application/json'}
        }
        fetch(url+'/categorias/',requestOptions)
        .then(response => response.json())
        .then(data => {console.log(data) 
            setCategorias(data)
        })
        .catch(error=>console.log('el error '+error))
    }
    useEffect(()=>{Listar()},[])
    return <div>
            <table className="table">
                <thead>
                    <tr><th>Lista de Categorias</th></tr>
                </thead>
                <tbody>
                    {
                        categorias.map(datos=>(
                            <tr>
                                <td>
                                    {datos.nombre}
                                </td>
                            </tr>
                        ))
                    }
                </tbody>
            </table>
        </div>
}